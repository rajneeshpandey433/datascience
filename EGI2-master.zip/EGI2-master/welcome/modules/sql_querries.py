import sqlite3
from sqlite3 import Error

def create_connection(db_file):
    """ create a database connection to a SQLite database """
    conn = None
    try:
        conn = sqlite3.connect(db_file)
        print(sqlite3.version)
    except Error as e:
        print(e)
    return conn

def select_point_by_esignum(conn, esignum):
    """
    Query tasks by priority
    :param conn: the Connection object
    :param priority:
    :return:
    """
    cur = conn.cursor()
    cur.execute("SELECT points FROM Points WHERE esignum=?", (esignum,))
    rows = cur.fetchone()
    return rows

def update_points(conn, task):
    sql = ''' UPDATE Points
              SET Points = ?
              WHERE esignum = ?'''
    cur = conn.cursor()
    cur.execute(sql, task)
    conn.commit()

def select_top5_points_holders(conn):
    """
    Query top 5 point holders
    :param conn: the Connection object
    :param priority:
    :return:
    """
    cur = conn.cursor()
    cur.execute("SELECT name,points FROM Points ORDER BY points DESC LIMIT 5",)
    rows = cur.fetchall()
    return rows

def select_player_from_login(conn,esignum):
    """
    Query Player
    :param conn: the Connection object
    :param priority:
    :return:
    """
    cur = conn.cursor()
    cur.execute("SELECT count(esignum) FROM Players WHERE esignum = ?",(esignum,))
    (num,) = cur.fetchone()
    return num

def select_player_from_points(conn,esignum):
    """
    Query Player
    :param conn: the Connection object
    :param priority:
    :return:
    """
    cur = conn.cursor()
    cur.execute("SELECT count(esignum) FROM Points WHERE esignum = ?",(esignum,))
    (num,) = cur.fetchone()
    return num

def insert_into_players(conn,esignum):
    cur = conn.cursor()
    cur.execute("INSERT INTO Players(Esignum,Password) VALUES(?,?)",(esignum,esignum,))
    conn.commit()

def insert_into_points(conn,esignum,name,points):
    cur = conn.cursor()
    cur.execute("INSERT INTO Points(esignum,name,points) VALUES(?,?,?)",(esignum,name,points,))
    conn.commit()
