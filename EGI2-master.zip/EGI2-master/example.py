

def getRemainder(num, divisor):
  return (num - divisor * (num // divisor))


import math
# Driver program to test above functions
num = 9
divisor = 14
print(math.floor(9/8+9/14))
