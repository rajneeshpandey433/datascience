import sqlite3
from sqlite3 import Error
def create_connection(db_file):
    """ create a database connection to a SQLite database """
    conn = None
    try:
        conn = sqlite3.connect(db_file)
        print(sqlite3.version)
    except Error as e:
        print(e)
    return conn

def insert_into_points(conn,esignum,name,points):
    cur = conn.cursor()
    cur.execute("INSERT INTO Points(esignum,name,points) VALUES(?,?,?)",(esignum,name,points,))
conn = create_connection(r"C:\sqlite\db\points.db")
insert_into_points(conn,"edsadada","dumbo",1000)
