import sqlite3
from sqlite3 import Error

def create_connection(db_file):
    """ create a database connection to a SQLite database """
    conn = None
    try:
        conn = sqlite3.connect(db_file)
        print(sqlite3.version)
    except Error as e:
        print(e)
    return conn

def select_point_by_esignum(conn, esignum):
    """
    Query tasks by priority
    :param conn: the Connection object
    :param priority:
    :return:
    """
    cur = conn.cursor()
    cur.execute("SELECT points FROM Points WHERE esignum=?", (esignum,))

    rows = cur.fetchall()

    return rows

def update_points(conn, task):
    sql = ''' UPDATE Points
              SET Points = ?
              WHERE esignum = ?'''
    cur = conn.cursor()
    cur.execute(sql, task)
    conn.commit()


def select_password_by_esignum(conn, esignum):
    """
    Query tasks by priority
    :param conn: the Connection object
    :param priority:
    :return:
    """
    cur = conn.cursor()
    cur.execute("SELECT Password FROM Players WHERE Esignum=?", (esignum,))

    rows = cur.fetchall()

    return rows
