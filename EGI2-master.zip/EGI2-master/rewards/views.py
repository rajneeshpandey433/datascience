from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import redirect

from .modules import sql_querries as sql_helper

from pymongo import MongoClient

import datetime

def index(request):
    return render(request, "rewards/rewards_index.html")

def coupons(request):
    Esignum = ""
    Password = ""
    if (request.method == "POST"):
        Esignum = request.POST["Esignum"]
        Password = request.POST["Password"]
    else:
        print("something is wrong")
        response = redirect("/")
        return (response)
    conn = sql_helper.create_connection(r"C:\sqlite\db\points.db")
    try:
        password = sql_helper.select_password_by_esignum(conn, Esignum)[0][0]
    except:
        response = redirect("/rewards")
        return(response)
    if (password == Password):
        points=sql_helper.select_point_by_esignum(conn, Esignum)[0][0]
        request.session["esignum"] = Esignum
        dic_list = []
        client = MongoClient()
        client = MongoClient('localhost', 27017)
        db = client.EGIgame.coupons
        for x in db.find():
            del x["_id"]
            text = "Claim "+ x["Coupon_name"]
            x["button"] = text
            dic_list.append(x)
            if (request.method == "post"):
                print(request.POST)
        return render(request,'rewards/rewards_coupons.html', {"parent_dict" : dic_list, "Esignum":Esignum, "points" : points})
    else:
        response = redirect("/rewards")
        return(response)

def success(request):
    text = ""
    coupon_id = ""
    coupon_points = 0
    player_points = 0
    esignum = request.session["esignum"]
    client = MongoClient()
    client = MongoClient('localhost', 27017)
    db_redeemed = client.EGIgame.redeemed
    db_coupons = client.EGIgame.coupons
    conn = sql_helper.create_connection(r"C:\sqlite\db\points.db")
    dic_list = []
    for x in db_coupons.find():
        del x["_id"]
        text = "Claim "+ x["Coupon_name"]
        x["button"] = text
        dic_list.append(x)
    if (request.method == "POST"):
        coupon_id = request.POST["coupon_id"]
        coupon_points = int(request.POST["coupon_points"])
        try:
            conn = sql_helper.create_connection(r"C:\sqlite\db\points.db")
            try:
                player_points = sql_helper.select_point_by_esignum(conn, esignum)[0][0]
                if (player_points < coupon_points):
                    text = "Low amount of points"
                else:
                    points_left = player_points - coupon_points
                    sql_helper.update_points(conn, (points_left, esignum))
                    text = esignum + " redeemed " + coupon_id
                    if (db_redeemed.find({"Esignum":esignum, "Coupon_id" : coupon_id}).count() > 0):
                        myquery = { "Esignum": esignum, "Coupon_id" : coupon_id }
                        document = db_redeemed.find_one(myquery)
                        quant = document["Quantity"]
                        newvalues = { "$set": { "Quantity": quant+1 } }
                        db_redeemed.update_one(myquery,newvalues)
                    else:
                        myquery = {
                        "Esignum" : esignum,
                        "Coupon_id" : coupon_id,
                        "Quantity" : 1,
                        "Time" : datetime.datetime.utcnow()
                        }
                        i = db_redeemed.insert_one(myquery)
            except Exception as e:
                print("problem in getting info back")
                print(e)
        except:
            print("problem occured")
    else:
        text = "Stop refreshing the page. It will not increase your points."
    points=sql_helper.select_point_by_esignum(conn, esignum)[0][0]
    return render(request,'rewards/rewards_redeemed.html', {"parent_dict" : dic_list, "Esignum":esignum, "points" : points , "alert_given" : text})
